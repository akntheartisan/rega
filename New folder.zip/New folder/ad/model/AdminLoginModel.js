const mongoose = require('mongoose');

const AdminLogin = new mongoose.Schema({
    username: {
        type:String
    },
    password: {
        type:String
    }
});

module.exports = mongoose.model('Admin',AdminLogin);